<!DOCTYPE html>
<html>
<head>
    <title>Product Inventory</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet">

</head>
<body>
    <div class="container">
        <h1>Product Inventory</h1>
        <form id="product-form" action="{{ url('/products') }}" method="POST">

            @csrf
            <div class="form-group">
                <label for="product_name">Product Name:</label>
                <input type="text" class="form-control" id="product_name" name="product_name" required>
            </div>
            <div class="form-group">
                <label for="quantity">Quantity in Stock:</label>
                <input type="number" class="form-control" id="quantity" name="quantity" required>
            </div>
            <div class="form-group">
                <label for="price">Price per Item:</label>
                <input type="number" step="0.01" class="form-control" id="price" name="price" required>
            </div>
            <button type="submit" class="btn btn-primary">Submit</button>
        </form>
        <br>
        <table class="table">
            <thead>
                <tr>
                    <th>Product Name</th>
                    <th>Quantity in Stock</th>
                    <th>Price per Item</th>
                    <th>Total Value</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody id="product-table">
            </tbody>
            <tfoot>
                <tr>
                    <td colspan="4" align="right"><strong>Total:</strong></td>
                    <td id="total-value"></td>
                    <td></td>
                </tr>
            </tfoot>
        </table>
    </div>

 <div class="modal fade" id="editProductModal" tabindex="-1" aria-labelledby="editProductModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="editProductModalLabel">Edit Product</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <form id="edit-product-form" method="post">
                        @csrf
                        <input type="hidden" id="edit-product-id" name="product_id">
                        <div class="form-group">
                            <label for="edit-product-name">Product Name:</label>
                            <input type="text" class="form-control" id="edit-product-name" name="product_name" required>
                        </div>
                        <div class="form-group">
                            <label for="edit-quantity">Quantity in Stock:</label>
                            <input type="number" class="form-control" id="edit-quantity" name="quantity" required>
                        </div>
                        <div class="form-group">
                            <label for="edit-price">Price per Item:</label>
                            <input type="number" step="0.01" class="form-control" id="edit-price" name="price" required>
                        </div>
                        <button type="submit" class="btn btn-primary">Save Changes</button>
                    </form>
                </div>
            </div>
        </div>
    </div>


   
    <script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"></script>
    


   <script>
    $(document).ready(function() {
         let editButton;
    loadProducts();

    function loadProducts() {
        $.get('/getData', function(response) {
            let totalValue = 0;
            $('#product-table').empty();
            if (Array.isArray(response)) {
                response.forEach(function(product) {
                    totalValue += parseFloat(product.total_value);
                    $('#product-table').append(`<tr>
                        <td>${product.product_name}</td>
                        <td>${product.quantity}</td>
                        <td>${product.price}</td>
                         <td><button class="btn btn-primary btn-sm edit-btn" data-bs-toggle="modal" data-bs-target="#editProductModal" data-product-id="${product.id}">Edit</button>
                                 <a href="{{url('/')}}/deleteProduct/${product.id}"><button class="btn btn-danger btn-sm delete-btn">Delete</button></a></td>
                        <td>${product.total_value}</td>
                    </tr>`);
                });
                $('#total-value').text(totalValue.toFixed(2));
            } else {
                console.error('Unexpected response format:', response);
            }
        }).fail(function(xhr, status, error) {
            console.error('Failed to load products. Status:', status, 'Error:', error);
        });
    }

    $('#editProductModal').on('show.bs.modal', function(event) {
                editButton = $(event.relatedTarget);
                var productId = editButton.data('product-id');
                var modal = $(this);

                $.get(`/edit/${productId}`, function(response) {
                    modal.find('#edit-product-id').val(response.id);
                    modal.find('#edit-product-name').val(response.product_name);
                    modal.find('#edit-quantity').val(response.quantity);
                    modal.find('#edit-price').val(response.price);
                }).fail(function(xhr, status, error) {
                    console.error('Failed to load product details. Status:', status, 'Error:', error);
                });
            });

            $('#edit-product-form').submit(function(event) {
                event.preventDefault();
                var formData = $(this).serialize();
                var productId = editButton.data('product-id');
                $.post(`/updateProduct/${productId}`, formData, function(response) {
                    $('#editProductModal').modal('hide');
                    loadProducts();
                }).fail(function(xhr, status, error) {
                    console.error('Failed to update product. Status:', status, 'Error:', error);
                });
            });
});



</script>

   
</body>
</html>
