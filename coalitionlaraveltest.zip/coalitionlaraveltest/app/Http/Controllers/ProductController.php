<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;
use App\Models\Product;

class ProductController extends Controller
{
    public function index()
    {
        $products = Product::all();
        return view('products', compact('products'));
    }

    public function store(Request $request)
    {
        $data = $request->validate([
            'product_name' => 'required|string',
            'quantity' => 'required|integer',
            'price' => 'required|numeric',
        ]);

        $data['total_value'] = $data['quantity'] * $data['price'];

        $product = Product::create($data);

        return redirect('/products');
    }
    public function getData()
    {
        $products=Product::all();
        return response()->json($products);
    }

    public function deleteProduct($id)
    {
        $product = Product::find($id);

        $product->delete();

        return redirect('/');
    }

    public function edit($id)
    {
        $product = Product::findOrFail($id);
        return response()->json($product);
    }


    public function updateProduct(Request $request, $id)
    {
        // Validate the request data
        $request->validate([
            'product_name' => 'required',
            'quantity' => 'required|integer|min:0',
            'price' => 'required|numeric|min:0.01',
        ]);

        // Find the product by ID
        $product = Product::findOrFail($id);

        // Update the product record
        $product->update([
            'product_name' => $request->input('product_name'),
            'quantity' => $request->input('quantity'),
            'price' => $request->input('price'),
            'total_value' => $request->input('quantity') * $request->input('price'),
        ]);

        // Redirect back to the product inventory page
        return redirect()->back();
    }

    

}
